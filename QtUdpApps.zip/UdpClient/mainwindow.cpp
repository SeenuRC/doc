#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostAddress>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , udpSocket(new QUdpSocket(this))
{
    ui->setupUi(this);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_sendButton_clicked() {
    QByteArray data = ui->lineEdit->text().toUtf8();
    udpSocket->writeDatagram(data, QHostAddress::LocalHost, 12345);
    ui->textEdit->append("Sent: " + ui->lineEdit->text());
    ui->lineEdit->clear();
}
