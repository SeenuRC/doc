#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), server(new Server(this)) {
    ui->setupUi(this);
    connect(server, &Server::messageReceived, ui->textEdit, &QTextEdit::append);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_startServerButton_clicked() {
    server->startServer(1234);
    ui->textEdit->append("Server started on port 1234...");
}