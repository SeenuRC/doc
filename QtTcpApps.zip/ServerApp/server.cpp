#include "server.h"
#include <QDebug>

Server::Server(QObject *parent) : QTcpServer(parent), clientSocket(nullptr) {}

void Server::startServer(quint16 port) {
    if (!listen(QHostAddress::Any, port)) {
        qDebug() << "Server could not start!";
    } else {
        qDebug() << "Server started on port" << port;
    }
}

void Server::incomingConnection(qintptr socketDescriptor) {
    clientSocket = new QTcpSocket(this);
    clientSocket->setSocketDescriptor(socketDescriptor);
    connect(clientSocket, &QTcpSocket::readyRead, this, &Server::readClientData);
}

void Server::readClientData() {
    QByteArray data = clientSocket->readAll();
    QString msg = QString::fromUtf8(data);
    emit messageReceived("Received: " + msg);
}