#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QTcpSocket>

class Server : public QTcpServer {
    Q_OBJECT

public:
    explicit Server(QObject *parent = nullptr);
    void startServer(quint16 port);

signals:
    void messageReceived(const QString &msg);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private slots:
    void readClientData();

private:
    QTcpSocket *clientSocket;
};

#endif // SERVER_H