#include "client.h"

Client::Client(QObject *parent) : QObject(parent), socket(new QTcpSocket(this)) {}

void Client::connectToServer(const QHostAddress &address, quint16 port) {
    socket->connectToHost(address, port);
}

void Client::sendMessage(const QString &msg) {
    if (socket->state() == QAbstractSocket::ConnectedState) {
        socket->write(msg.toUtf8());
    }
}