#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), client(new Client(this)) {
    ui->setupUi(this);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_connectButton_clicked() {
    client->connectToServer(QHostAddress::LocalHost, 1234);
    ui->textEdit->append("Connected to server.");
}

void MainWindow::on_sendButton_clicked() {
    QString msg = ui->lineEdit->text();
    client->sendMessage(msg);
    ui->textEdit->append("Sent: " + msg);
}