#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>

class Client : public QObject {
    Q_OBJECT

public:
    explicit Client(QObject *parent = nullptr);
    void connectToServer(const QHostAddress &address, quint16 port);
    void sendMessage(const QString &msg);

private:
    QTcpSocket *socket;
};

#endif // CLIENT_H